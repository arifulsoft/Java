
package Project5;

import java.util.Scanner;
public class Question4 {
     public static void main(String [] args){
 Scanner input=new Scanner(System.in); 
 
 int number, squer;
 System.out.println("Enter your first Number:");
 number=input.nextInt();
 
 squer=number*number;
 
  System.out.println("Sqoer:"+squer);
 
 
 
}
}