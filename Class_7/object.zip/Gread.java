
package object;


public class Gread {
      public static void main(String[] args) {
          
      }
      
}
