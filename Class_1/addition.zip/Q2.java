
package addition;

import java.util.Scanner;
public class Q2 {
    public static void main(String [] args){
Scanner sc=new Scanner(System.in);
     System.out.println("First emplyees");
     int x1=sc.nextInt();
      System.out.println("Secound employees");
       int x2= sc.nextInt();
       System.out.println("Thard employees");
     int x3= sc.nextInt();
     int c=(x1+x2+x3)/3;
     System.out.println("Avarg = "+c);
    
}
}
