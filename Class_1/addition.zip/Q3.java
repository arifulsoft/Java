
package addition;
import java.util.Scanner;

public class Q3 {


    

    
     public static void main(String [] args){  
         
        Scanner sc=new Scanner(System.in);
         System.out.println("My id");
      String a1=sc.nextLine();
         System.out.println("My name is " );
     String a2=sc.nextLine();
     System.out.println("My Round " );
     String a3=sc.nextLine();
     
     
      System.out.println("MCQ");
      int x1=sc.nextInt();
       System.out.println("Practical");
        int x2= sc.nextInt();
         int c=(x1+x2);
       int d=(+x1+x2)/3;
       
       System.out.println("My id number: " +a1);
       System.out.println("My name is: " +a2);
       System.out.println("My round: " +a3);
       System.out.println("MCQ Mark: " +x1);
       System.out.println("Practical mark: " +x2);
       System.out.println("Total number: " +c);
        System.out.println("Avarg: " +d);
        

    
}
}

