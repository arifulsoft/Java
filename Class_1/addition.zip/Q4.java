
package addition;
import java.util.Scanner;
public class Q4 {
    public static void main(String [] args){
   
        Scanner sc=new Scanner(System.in);
         System.out.println("kilometer");
     double a1=sc.nextDouble();
      double c=a1*0.621371;
     System.out.println("Miles: " +c);
    } 
}
