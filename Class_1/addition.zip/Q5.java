
package addition;

import java.util.Scanner;
public class Q5 {
    public static void main(String [] args){
   
        Scanner sc=new Scanner(System.in);
       System.out.println("Enter your value");
       double x=sc.nextDouble();
        if(x<0){
             System.out.println("Negative");
        }else if(x>0){
       System.out.println("Possetive");
        }
              
        
    
    } 
}
