
package addition;

import java.util.Scanner;
public class Q1 {
     public static void main(String [] args){
        Scanner sc=new Scanner(System.in);
      System.out.println("Math");
       int x1=sc.nextInt();       System.out.println("English");
      int x2= sc.nextInt();
       System.out.println("Science");        int x3= sc.nextInt();        System.out.println("Zoology");
        int x4= sc.nextInt();
       int c=x1+x2+x3+x4;
       System.out.println("Total sumession is= " + c);   
    
}
}
