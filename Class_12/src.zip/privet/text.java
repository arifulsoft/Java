package privet;

public class text {

    public static void main(String[] args) {
        y s1 = new y();
       z s2=new z();
       z s3=new z(104,"Asik");
       
          System.out.println(s3.ename);
          System.out.println(s2.ename);
          System.out.println(s1.x2);
          System.out.println(s2.eid);
       //System.out.println(s1.id);
       //System.out.println(s1.name);
          
      
    }
}
