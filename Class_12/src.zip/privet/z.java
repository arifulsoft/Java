
package privet;

public class z {
    int eid;
    String ename="asd";

    public z(int eid, String ename) {
        this.eid = eid;
        this.ename = ename;
    }

    public z() {
    }

    
    
}
