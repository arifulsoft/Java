
package privet;


public class y  extends x {
    int x1;
    String x2;

    public y() {
    }

    public y(int x1, String x2) {
        this.x1 = x1;
        this.x2 = x2;
    }

   
    
}
