package privet;

public class x {

    private int id = 101;
    private String name = "Dhaka";
    public int round = 57;

    public x() {
    }



}
