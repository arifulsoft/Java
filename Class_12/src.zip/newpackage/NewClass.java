
package newpackage;
import privet.x;
public class NewClass {
    public static void main(String[] args) {
        x sw= new x();
        System.out.println(sw.round);
    }
}
