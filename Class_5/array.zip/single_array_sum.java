
package array;


public class single_array_sum {
    public static void main(String[] args){
        int x[]={2,4,6,3};
        int sum=0;
        for(int i=0; i<x.length;i++){
            sum=sum+x[i];
        }
    }
}
