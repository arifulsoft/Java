
package project6;


public class justeven {
    public static void main(String[] args) {
        int sum=0;
       for(int i=0;i<=10;i++){
          
               sum=sum+i;
          
           }
        System.out.println(sum);
       }   
}
