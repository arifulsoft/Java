
package project6;
import java.util.Scanner;
public class even_odd {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter your Value");
        int x=sc.nextInt();
        if(x%2==0){
        System.out.println("Even number");
        }else{
            System.out.println("Odd number");
        }
    
}
}