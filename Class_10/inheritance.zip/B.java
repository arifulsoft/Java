package inheritance;

public class B extends A {

    int x1 = 20;
    String x2 = "Raj";

     B() {
    }
    

}
