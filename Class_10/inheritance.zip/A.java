package inheritance;

public class A {

    int x = 5;
    String y = "Rahim";

    public A() {
    }

}
