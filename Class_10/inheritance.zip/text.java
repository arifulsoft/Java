package inheritance;

public class text {

    public static void main(String[] args) {
        A a1 = new A();
        B a2 = new B();

        System.out.println(a1.x);
        System.out.println(a2.y);
        System.out.println(a2.x1);
        System.out.println(a2.x2);
    }
}
