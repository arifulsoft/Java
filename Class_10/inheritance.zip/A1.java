
package inheritance;


public class A1 {
    int x;
    String y;

    public A1() {
    }

    public A1(int x, String y) {
        this.x = x;
        this.y = y;
    }
    
}
